const envelope = [];


function SingleEnvelope(category, uniqueID, expenseBudget) {
	envelope.push({ category, uniqueID, expenseBudget });

	return envelope;
}


function returnEnvelop(envelopeArray) {
	return envelopeArray
}

SingleEnvelope("mac", 1, 0);
// SingleEnvelope("andy", 3, 0);
// //console.log(SingleEnvelope("mac", 1, 0));
// console.log(SingleEnvelope("mac", 2, 0));
// SingleEnvelope("andy", 4, 0)

